/**
 * Created by Lenovo on 2016/4/29.
 */

exports.world=function(){
    console.log("hello world")
}
